/*
 ================================================================================================
 Name        : distance_us.c
 Author      : Mostafa Kotb
 Description : measure the distance using ultrasonic sensor HC-SR04
 Date        : 13/10/2022
 ================================================================================================
 */

#include "lcd.h"
#include "ultrasonic.h"
#include "icu.h"
#include <avr/io.h>

int main(void)
{
	/* set interrupt */
	SREG |= (1<<7);
	/* initialize all drivers */
	LCD_init();
	Ultrasonic_init();

	uint16 distance=0;
	while(1)
	{
		/* Display the string*/
		LCD_displayStringRowColumn(0, 0, "Distance = ");

		distance = Ultrasonic_readDistance();
		LCD_intgerToString(distance);
		if (distance<10)
		{
			LCD_displayCharacter(' ');
			LCD_displayCharacter(' ');
		}
		else if(distance>=10 && distance<100)
		{
			LCD_displayCharacter(' ');
		}
		LCD_displayStringRowColumn(0, 14, "cm");
	}
}
