/*
 ============================================================================
 Name        : fan_controller.c
 Author      : Mostafa Kotb
 Description : Implementing a Fan Controller system
 Date        : 7/10/2022
 ============================================================================
 */

/***************************************************************************
 * 								Includings								   *
 ***************************************************************************/

#include "lm35_sensor.h"
#include "dc_motor.h"
#include "adc.h"
#include "lcd.h"
#include "gpio.h"

/***************************************************************************
 * 								main function							   *
 ***************************************************************************/

int main (void)
{
	ADC_ConfigType variable = {INTERNAL_2560_MILLI_VOLT, F_CPU_DIV_BY_8};
	uint8 temp;

	/* initialize all drivers */
	ADC_init(&variable);
	LCD_init();
	DcMotor_Init();
	/* Display the string*/
	LCD_displayString("Fan is ");
	LCD_displayStringRowColumn(1,0,"TEMP =     C");
	while(1)
	{
		/*read from channel 2*/
		ADC_readChannel (ADC2);

		temp = LM35_getTemperature();
		/* Display the temperature value every time at same position */
		if(temp < 30)
		{
			/*If the temperature is less than 30C turn off the fan.*/
			LCD_displayStringRowColumn(0,8,"OFF");
			DcMotor_Rotate(DC_MOTOR_STOP , 0);
		}
		else if ( (temp >= 30) && (temp < 60))
		{
			/*If the temperature is greater than or equal 30C turn on the fan with 25% of its maximum speed.*/
			LCD_displayStringRowColumn(0,8,"ON ");
			DcMotor_Rotate(DC_MOTOR_CLOCKWISE_ROTATION , 64);
		}
		else if ( (temp >= 60) && (temp < 90))
		{
			/*If the temperature is greater than or equal 60C turn on the fan with 50% of its maximum speed.*/
			LCD_displayStringRowColumn(0,8,"ON ");
			DcMotor_Rotate(DC_MOTOR_CLOCKWISE_ROTATION , 128);
		}
		else if ( (temp >= 90) && (temp < 120))
		{
			/*If the temperature is greater than or equal 90C turn on the fan with 75% of its maximum speed.*/
			LCD_displayStringRowColumn(0,8,"ON ");
			DcMotor_Rotate(DC_MOTOR_CLOCKWISE_ROTATION , 192);
		}
		else
		{
			/*If the temperature is greater than or equal 120C turn on the fan with 100% of its maximum speed.*/
			LCD_displayStringRowColumn(0,8,"ON ");
			DcMotor_Rotate(DC_MOTOR_CLOCKWISE_ROTATION , 255);
		}

		LCD_moveCursor(1,7);
		if(temp >= 100)
		{
			LCD_intgerToString(temp);
		}
		else
		{
			LCD_intgerToString(temp);
			/* In case the digital value is two or one digits print space in the next digit place */
			LCD_displayCharacter(' ');
		}

	}
}
