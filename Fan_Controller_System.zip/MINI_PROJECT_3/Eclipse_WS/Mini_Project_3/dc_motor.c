/******************************************************************************
 *
 * Module: dc_motor
 *
 * File Name: dc_motor.c
 *
 * Description: Source file for the DC_MOTOR driver
 *
 * Author: Mostafa Kotb
 *
 *******************************************************************************/

#include "dc_motor.h"
#include "gpio.h"
#include "pwm.h"
/*******************************************************************************
 *                      Functions Definitions                                   *
 *******************************************************************************/
/*
 * Description :
 * Initialize the DC_Motor:
 * 1. setup the direction for the two motor pins through the GPIO driver.
 * 2. Stop at the DC-Motor at the beginning through the GPIO driver.
 */
void DcMotor_Init(void)
{
	/* set the 2 pins (INPUT1 , INPUT2) as output pins*/
	GPIO_setupPinDirection(L293D_CHIP_IN1_PORT_ID, L293D_CHIP_IN1_PIN_ID, PIN_OUTPUT);
	GPIO_setupPinDirection(L293D_CHIP_IN2_PORT_ID, L293D_CHIP_IN2_PIN_ID, PIN_OUTPUT);
	GPIO_writePin(L293D_CHIP_IN1_PORT_ID, L293D_CHIP_IN1_PIN_ID, LOGIC_LOW);
	GPIO_writePin(L293D_CHIP_IN2_PORT_ID, L293D_CHIP_IN2_PIN_ID, LOGIC_LOW);
}

/*
 * Description :
 * The function responsible for rotate the DC Motor CW/ or A-CW or stop the motor
 * based on the state input state value.
 * Send the required duty cycle to the PWM driver based on the required speed value.
 */
void DcMotor_Rotate(DcMotor_State state,uint8 speed)
{
	PWM_Timer0_Start(speed);

	switch (state)
	{
	case DC_MOTOR_STOP:
		GPIO_writePin(L293D_CHIP_IN1_PORT_ID, L293D_CHIP_IN1_PIN_ID, LOGIC_LOW);
		GPIO_writePin(L293D_CHIP_IN2_PORT_ID, L293D_CHIP_IN2_PIN_ID, LOGIC_LOW);
		break;
	case DC_MOTOR_CLOCKWISE_ROTATION:
		GPIO_writePin(L293D_CHIP_IN1_PORT_ID, L293D_CHIP_IN1_PIN_ID, LOGIC_HIGH);
		GPIO_writePin(L293D_CHIP_IN2_PORT_ID, L293D_CHIP_IN2_PIN_ID, LOGIC_LOW);
		break;
	case DC_MOTOR_ANTICLOCKWISE_ROTATION:
		GPIO_writePin(L293D_CHIP_IN1_PORT_ID, L293D_CHIP_IN1_PIN_ID, LOGIC_LOW);
		GPIO_writePin(L293D_CHIP_IN2_PORT_ID, L293D_CHIP_IN2_PIN_ID, LOGIC_HIGH);
		break;
	}
}
