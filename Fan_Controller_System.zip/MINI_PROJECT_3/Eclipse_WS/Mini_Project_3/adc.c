/******************************************************************************
 *
 * Module: ADC
 *
 * File Name: adc.c
 *
 * Description: Source file for the ATmega32 ADC driver
 *
 * Author: Mostafa Kotb
 *
 *******************************************************************************/


#include "avr/io.h" /* To use the ADC Registers */
#include "adc.h"
#include "common_macros.h" /* To use the macros like SET_BIT */

/*******************************************************************************
 *                      Public Global Variables Definitions                    *
 *******************************************************************************/
/*
 *  It is used to save the reference voltage at any mode at all dynamic
 *  configurations
 */
volatile float32 g_referenceVoltage_ADC = 0 ;


/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/


void ADC_init(const ADC_ConfigType * Config_Ptr)
{
	/*
	 *  ADMUX register bit selection :
	 *  1)REFS1:0 = we set this two bits according to the
	 *    dynamic configuration that is supplied by the user either choosing internal
	 *    mode or External AREF or use the AVCC as reference.
	 *  2)ADLAR   = 0 right adjusted
	 *  3)MUX4:0  = 00000 to choose channel 0 as initialization
	 */
	ADMUX = (Config_Ptr->ref_volt) << 6;

	/* ADCSRA Register Bits Description:
	 * ADEN    = 1 Enable ADC
	 * ADIE    = 0 Disable ADC Interrupt
	 * ADATE   = 0 Disable Auto Trigger
	 * ADPS2:0 = 011 to choose ADC_Clock = F_CPU/8 = 1Mhz/8 = 125Khz --> ADC must operate in range 50-200Khz
	 */
	ADCSRA = (1<<ADEN) | (Config_Ptr->prescaler);
	/* We will save the value of reference voltage in all voltage reference
	 *  selection options in ADC
	 */

	if( (Config_Ptr ->ref_volt) == INTERNAL_2560_MILLI_VOLT )
	{
		/* In case of using internal Voltage the value will be 2.56	*/
		g_referenceVoltage_ADC = 2.56;
	}
	else if( (Config_Ptr ->ref_volt) == AVCC_5V)
	{
		/*	In case of choosing AVCC as a reference so the value will be 5	*/
		g_referenceVoltage_ADC = 5;
	}
	else if(  (Config_Ptr ->ref_volt) == EXTERNAL_AREF)
	{
		/*	If the user want a specific voltage so he will supply it to AREF pin
		 *  and he need to modify this value as a static configurations , then
		 *  saving this value in the global variable
		 */
		g_referenceVoltage_ADC = ADC_EXTERNAL_REF_VOLT_VALUE ;
	}
}

/*
 * Description:
 * we have 8 channel of ADC and we can use only one channel at a time so we need
 * to know which channel are we going to work with.
 * This function takes the input channel as input and activates the ADC
 * and convert the current analog value at the input pin to a digital value and
 * return it.
 */
uint16 ADC_readChannel (uint8 ch_num)
{
	ch_num &= 0x07; /* Input channel number must be from 0 --> 7 */
	ADMUX &= 0xE0; /* Clear first 5 bits in the ADMUX (channel number MUX4:0 bits) before set the required channel */
	ADMUX = ADMUX | ch_num; /* Choose the correct channel by setting the channel number in MUX4:0 bits */
	SET_BIT(ADCSRA,ADSC); /* Start conversion write '1' to ADSC */
	while(BIT_IS_CLEAR(ADCSRA,ADIF)); /* Wait for conversion to complete, ADIF becomes '1' */
	SET_BIT(ADCSRA,ADIF); /* Clear ADIF by write '1' to it :) */
	return ADC; /* Read the digital value from the data register */
}
