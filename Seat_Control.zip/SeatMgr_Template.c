/**
 *
 * \file SeatMgr_Template.c
 * \brief Rte Component Template for AUTOSAR SWC: SeatMgr
 *
 * \author Sprints AUTOSAR Authoring Tool (SAAT) v1.0.2
 * Generated on 9/5/2023 03:52 PM
 *
 * For any inquiries: hassan.m.farahat@gmail.com
 *
 */

#include "Rte_SeatMgr.h"

static boolean IsMotorAdjustNeeded( SensorPositionType Position, SensorWeightType Weight, StepMotorStepType *Step)
{
	boolean adjustMotor = FALSE;
	
	switch(Position)
	{
		case SENSOR_POSITION_STEP_0:
			if (weight > 60)
			{
				Step = MOTOR_STEP_PLUS;
				adjustMotor = TRUE;
			}
			break;
			
		case SENSOR_POSITION_STEP_1:
			if (weight > 80)
			{
				Step = MOTOR_STEP_PLUS;
				adjustMotor = TRUE;
			}
			else if(weight <= 80 && weight >= 60)
			{
				/* LEAVE POSITION STABLE*/
			}
			else
			{
				Step = MOTOR_STEP_MINUS;
				adjustMotor = TRUE;
			}
			break;
			
		case SENSOR_POSITION_STEP_2:
			if (Weight > 100)
			{
				Step = MOTOR_STEP_PLUS;
				adjustMotor = TRUE;
			}
			else if (Weight <= 100 && Weight >= 80) 
			{
				/* LEAVE POSITION STABLE*/				
			}
			else
			{
				Step = MOTOR_STEP_MINUS;
				adjustMotor = TRUE;
			}
			break;
			
		case SENSOR_POSITION_STEP_3:
			if (Weight < 100)
			{
				Step = MOTOR_STEP_MINUS;
				adjustMotor = TRUE;
			}
			break;
		default:
			break;
	}
	return adjustMotor;
}
/**
 *
 * Runnable SeatMgr_AutoHeight
 *
 * Triggered By:
 *  - TimingEventImpl.TE_SeatMgr_AutoHeight_200ms
 *
 */

void SeatMgr_AutoHeight (void)
{
	Std_ReturnType status;
	StepMotorStepType Step;
	SensorPositionType position;
	SensorWeightType weight;

	/* Server Call Points */
	status = Rte_Call_rpHeightSensor_GetPosition(&position);
	status = Rte_Call_rpWeightSensor_GetWeight(&weight);
	
	adjustMotor = IsMotorAdjustNeeded(position, weight, &Step);
	if (adjustMotor)
			status = Rte_Call_rpHeightMotor_Move(Step);
}


/**
 *
 * Runnable SeatMgr_AutoIncline
 *
 * Triggered By:
 *  - TimingEventImpl.TE_SeatMgr_AutoIncline_200ms
 *
 */

void SeatMgr_AutoIncline (void)
{
	Std_ReturnType status;
	StepMotorStepType Step;
	SensorPositionType position;
	SensorWeightType weight;

	/* Server Call Points */
	status = Rte_Call_rpInclineSensor_GetPosition(&position);
	status = Rte_Call_rpWeightSensor_GetWeight(&weight);
	
	adjustMotor = IsMotorAdjustNeeded(position, weight, &Step);
	if (adjustMotor)
			status = Rte_Call_rpInclineMotor_Move(Step);
}


/**
 *
 * Runnable SeatMgr_AutoSlide
 *
 * Triggered By:
 *  - TimingEventImpl.TE_SeatMgr_AutoSlide_200ms
 *
 */

void SeatMgr_AutoSlide (void)
{
	Std_ReturnType status;
	StepMotorStepType Step;
	SensorPositionType position;
	SensorWeightType weight;

	/* Server Call Points */
	status = Rte_Call_rpSlideSensor_GetPosition(&position);
	status = Rte_Call_rpWeightSensor_GetWeig
	
	adjustMotor = IsMotorAdjustNeeded(position, weight, &Step);
	if (adjustMotor)
			status = Rte_Call_rpSlideMotor_Move(Step);
}


/**
 *
 * Runnable SeatMgr_SetHeight
 *
 * Triggered By:
 *  - DataReceivedEventImpl.DRE_rpSeatCtrlBtns_HeightBtnState
 *
 */

void SeatMgr_SetHeight (void)
{
	Std_ReturnType status;
	MultiStateBtnType HeightBtnState;
	StepMotorStepType Step;

	/* Data Receive Points */
	status = Rte_Read_rpSeatCtrlBtns_HeightBtnState(&HeightBtnState);
	
	/* Server Call Points */
	status = Rte_Call_rpHeightMotor_Move(Arg_Step);
	if( HeightBtnState == MULTI_STATE_BTN_MINUS)
		Rte_Call_rpHeightMotor_Move(MOTOR_STEP_MINUS);
	if( HeightBtnState == MULTI_STATE_BTN_PLUS)
		Rte_Call_rpHeightMotor_Move(MOTOR_STEP_PLUS);
	
}


/**
 *
 * Runnable SeatMgr_SetIncline
 *
 * Triggered By:
 *  - DataReceivedEventImpl.DRE_rpSeatCtrlBtns_InclineBtnState
 *
 */

void SeatMgr_SetIncline (void)
{
	Std_ReturnType status;
	MultiStateBtnType InclineBtnState;
	StepMotorStepType Step;

	/* Data Receive Points */
	status = Rte_Read_rpSeatCtrlBtns_InclineBtnState(&InclineBtnState);
	
	/* Server Call Points */
	status = Rte_Call_rpInclineMotor_Move(Arg_Step);
	if( InclineBtnState == MULTI_STATE_BTN_MINUS)
		Rte_Call_rpInclineMotor_Move(MOTOR_STEP_MINUS);
	if( InclineBtnState == MULTI_STATE_BTN_PLUS)
		Rte_Call_rpInclineMotor_Move(MOTOR_STEP_PLUS);
	
}


/**
 *
 * Runnable SeatMgr_SetSlide
 *
 * Triggered By:
 *  - DataReceivedEventImpl.DRE_rpSeatCtrlBtns_SlideBtnState
 *
 */

void SeatMgr_SetSlide (void)
{
	Std_ReturnType status;
	MultiStateBtnType SlideBtnState;
	StepMotorStepType Step;

	/* Data Receive Points */
	status = Rte_Read_rpSeatCtrlBtns_SlideBtnState(&SlideBtnState);
	
	/* Server Call Points */
	status = Rte_Call_rpSlideMotor_Move(Arg_Step);
	if( SlideBtnState == MULTI_STATE_BTN_MINUS)
		Rte_Call_rpSlideMotor_MoveMotor_Move(MOTOR_STEP_MINUS);
	if( SlideBtnState == MULTI_STATE_BTN_PLUS)
		Rte_Call_rpSlideMotor_MoveMotor_Move(MOTOR_STEP_PLUS);	
	
}

