/*
NAME : 				MOSTAFA ASHRAF HASSAN KOTB
PROJECT NAME:		STOP_WATCH
DATE:				16/9/2022
 */
/*****************************************************************************************/


#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

//global variables
unsigned char g_tick = 0;
unsigned char seconds=0 , minutes=0 , hours=0;

/* Interrupt Service Routine for timer1 compare mode */
ISR (TIMER1_COMPA_vect)
{
	g_tick++;
/*check that each 1000ms increment the second and after 60 sec increment the minutes*/
	if (g_tick == 1 )
	{
		seconds++;
		g_tick = 0;
		if(seconds == 60)
		{
			minutes++;
			seconds=0;
		}
		if(minutes == 60)
		{
			hours++;
			minutes = 0;
			seconds = 0;
		}
	}
}

/* Interrupt Service Routine for interrupt 0 */
ISR (INT0_vect)
{

			seconds=0;	//reset the stop watch seconds, minutes and hours
			minutes=0;
			hours=0;

}

/* Interrupt Service Routine for interrupt 1 */
ISR (INT1_vect)
{
			//stop the clock timer
			TCCR1B &= ~ (1<<CS12) &~ (1<<CS10);

}

/* Interrupt Service Routine for interrupt 2 */
ISR (INT2_vect)
{
			//resume the timer
			TCCR1B |= (1<<CS12) | (1<<CS10);
}

// FUNCTION FOR TIMER1_CTC
void TIMER1_CTC (void)
{
	/*
	 * 1.Activating The FOC1A as it is NON-PWM.
	 * 2.Set OC1A on compare match.
	 * 3.Timer/Counter Mode of operation is CTC.
	 * 4.Prescalar = 1024.
	 */
	TCNT1 = 0;     			//STARTING THE COUNTER FROM ZERO
	TIMSK |= (1<<OCIE1A);   //Setting The Output Compare B Match Interrupt Enable
	OCR1A = 1000;			//SETTING THE OUTPUT COMPARE REGISTER WITH 800 STEPS.
	TCCR1A = (1<<FOC1A);
	TCCR1B = (1<<WGM12) | (1<<CS12) | (1<<CS10);
}

// FUNCTION FOR INTERRUPT0
void INT0_INIT (void)
{
	DDRD &= ~ (1<<PD2);			//setting pinD2 as an input
	PORTD|= (1<<PD2);			//enable pull up
	MCUCR |= (1<<ISC01);		//Falling edge
	MCUCR &= ~(1<<ISC00);
	GICR |= (1<<INT0);			//we are dealing with interrupt 0

}

// FUNCTION FOR INTERRUPT1
void INT1_INIT (void)
{
	DDRD &= ~ (1<<PD3); 					//setting pinD3 as an input
	MCUCR |= (1<<ISC10) | (1<<ISC11);		//Rising edge
	GICR |= (1<<INT1);						//we are dealing with interrupt 1
}

// FUNCTION FOR INTERRUPT2
void INT2_INIT (void)
{
	DDRB &= ~ (1<<PB2);					//setting pinB2 as an input
	PORTB|= (1<<PB2);					// internal pull up
	MCUCSR &= ~ (1<<ISC2);				//Falling edge
	GICR |= (1<<INT2);					//we are dealing with interrupt 2
}

//function to display the numbers on the 7 segments
void output(int value, int pin_number)
{
	PORTA = (1 << pin_number);
	PORTC = value;
}

int main (void)
{


	// SETTING THE OUTPUT PINS
	DDRA |= 0x3F;
	PORTA |= 0x3F;
	DDRC |= 0x0F;
	PORTC &= 0xF0;

	TIMER1_CTC();
	INT0_INIT();
	INT1_INIT();
	INT2_INIT();
	SREG = SREG | (1<<7);						// set interrupt (I-bit)

	while (1)
	{//displaying the numbers on the 7 segments
		output(seconds % 10, PA5);
		_delay_ms(2);
		output(seconds / 10, PA4);
		_delay_ms(2);
		output(minutes % 10, PA3);
		_delay_ms(2);
		output(minutes / 10, PA2);
		_delay_ms(2);
		output(hours % 10, PA1);
		_delay_ms(2);
		output(hours / 10, PA0);
		_delay_ms(2);
	}
}

